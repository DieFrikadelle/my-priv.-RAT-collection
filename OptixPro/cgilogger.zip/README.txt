
 ** SUBSEVEN LOGGER V1.2 **
	please read this file before your run or upload any files to your serve.

 ** VERSION NOTES FROM BLACK **
 
	Oh yea, i must address the issue of ICQ first.  I provided my icq number to help, 
	read this and understand it before you contect me. NO EXCEPTIONS....
		1) dont try to add me until i add you.
		2) dont use a program to force me to autorize (if you do, i will find you)
		3) dont make your first message to me, a request for authorization
		4) ask before requesting
		5) I DO NOT ACCEPT FILES
		6) im glad you like the script, but please dont message me for that sole
			perpose only.
		7) im only here to help with the logger, not subseven.  dont ask about 
			plugins or any other subseven related informaion, thats not
			my depo.
		
		and with that said.  enjoy the logger.
	
	
	well, i have been taking your requests, and adding in some of my own.  I have
	also been working to get the connection type added to the list.  This feature
	should be available in subseven 2.3, however between 1.0 and now, I have 
	improved the logging methods, added several features.  Please continue to send
	me requests, as i can only improve the script from my own ideas for so long.
	
	I AM TEMPORARALY LOOKING FOR AN IRC HOST.  irc.black-fire.net should be available
	very shortly, however until it is, i need a host.  If you run a host, please 
	e-mail me, and tell me.  however here are some of the requirements:
			1) No flood text limits
			2) few ircops (that aren't ass holes)
			3) allows mIRC bots.
	
	And for those of you who don't have the time to get users, there is a list of users
	available on the black-fire.net site.  PLEASE ADD USERS TOO IT.  i added a shit load
	myself, i want to start seeing some from your people.
	
	The most recent version of subseven logger, and always be found at the black-fire.net
	site, and if not there, with the newest version of subseven.
	
 ** FEATURE LIST **
 	
 	+Version 1.0
 	  - Color settings
 	  - Font settings
 	  + Admin menu
 	     - clear list
 	     - kill switch
 	     - add and remove members
    	     - change settings
 	     - change password and username
 	  - about screen with live pager
 	  - multi user support
 	  - require logging key
 	  - brute force prevention
 	  - security instruction
 	  - date and time display
 	  - overwrite old ip addresses (1 level)
 	  - delete ips older then X amount of days
 	  - easy form setup file
 	
 	+Version 1.1
 	  - address book
 	  - add address to address book
 	  - remove address from address book
 	  - overwrite old ip addresses (3 level)
 	  - network detection, and display
 	  
 	+Version 1.2
 	  - Log search engine with wild card support
 	  - member message (with customizable variables)
 	  - receives connection type (if implemented)
 	  - set font size
 	  - disable options
 	  - overwrite old ip addresses (4 level)
 	  
 	  
 ** DOES YOUR SERVER SUPPORT CGI **
	You cant go any further if your server does not offer cgi access.  It is not
	hard however to get a free host that offers CGI access.  Here is a list of 
	sites that support CGI access and are free.

            SITE ADDRESS     |    GRADE     |  ADD BANNER REMOVAL
          ---------------------------------------------------------
	  www.virtualave.net | **** A+ **** |  Easy as hell
	  www.hypermart.net  | **** C+ **** |  Easy as hell
          www.netfirms.com   |   UN-REATED  |  NOT TESTED
          www.nfs.com        |   UN-REATED  |  NOT TESTED
          www.vr9.com        | **** B- **** |  Some what easy


	if you know of anymore, please e-mail black@black-fire.net.
	here is a list of free hosts that DO NOT support cgi access.

              SITE ADDRESS    |    GRADE     |  ADD BANNER REMOVAL
          ---------------------------------------------------------
	  www.angelfire.com   | **** A- **** |  SOME WHAT easy
	  www.freeservers.com | **** D- **** |  Impossible
          www.tripod.com      | **** B  **** |  Easy
          www.geocities.com   | **** B  **** |  Little difficult.


	if you know of anymore, please e-mail black@black-fire.net

 ** LOCATION OF FILES **
	You must put all of the subseven log files in your cgi-bin.  If you don't
	have a cgi bin, but you know your server supports cgi access, then you 
	most likely can put the files in any folder.  However to keep your site 
	clean, and organized you should make a cgi-bin and put all of your cgi 
	programs in it.

 ** REQUIRED RAW CHANGES **
	Because your server may have several versions of PERL, you are required to
	put the correct path to PERL version 4 or 5 on the first line of every cgi
	file.  that would be every file that ends in ".cgi".  The location of PERL
	can usually be found by ether looking in your hosts FAQ for "CGI" or contacting
	your host and asking "Where is PERL located on your servers?".

	However most of the time the location of PERL is very similar to all servers.
	So try using the scripts on your server without editing them.  if you get a
	500 error or you see the source of the file, you need to change the location 
	of PERL.

	I will accept requests to install this script on your server for you.  so if you
	have trouble, just ask.  however I will require your FTP server address and your 
	username and password (I can be trusted).

 ** CHMOD OF FILES ** 
	CHMOD is a permission setting of a file.  What this will do is make all the setting
	files private to you alone.  If you fail to CHMOD correctly, ether the program will
	not work or your passwords will be easy to recover by anyone on the net.

	The first thing you need to set the CHMOD of a file on your server, is to get an FTP
	program.  An FTP (file transfer protocol) program will allow you to upload, edit,
	delete, CHMOD, move, and other file manipulations.  A good and free FTP program is
	cuteFTP (made by global scape).  Because most user friendly FTP programs are very 
	similar to cuteFTP, that is what I will concentrate on.

	Read all steps before you perform them 
	  1) upload all files to a new folder in your CGI-BIN
	  2) DO NOT RENAME ANY OF THE FILES
	  3) in the window that shows the files you just uploaded (the server side) right click
		on the files.  A little menu will popup, asking you what you want to do to the  
		file.  one of the selections should be CHMOD.  select that option.
	  4) CHMOD the ".cgi" files to 755
	  5) CHMOD the rest of the files to 600
 
 ** UPLOADING HELP **
	alright, i am getting pissed at the constant requests to install peoples CGI scripts
	I will not help you if you don't try to do it yourself first.  I don't know if i can 
	make it any easier, but chances are that if you cant do it, you shouldn't be using it.
	
	MAKE SURE THE FILES ARE UPLOADED IN ASCII.  if you use a web based file manager for your
	site, such as the one virtualave has, you cant upload the files that way, however you can
	created empty files with the same names as those required for the cgi script, and past the
	code inside them.  That will work.
	
	ALL FILES MUST GO IN THE SAME DIRECTORY.  all files must be in the same folder.  and if your
	on a virtual domain host, and they give you access to a non public folder, all files MUST
	then be placed within the PUBLIC_HTML folder.  if your not sure what that is, put the cgi
	file in the same DIR as your index HTML document.  you should be able to find this type
	of information in the FAQ of your host.


 ** USING THE SETUP.CGI file **
	When you have finished uploading and CHMODing all the files, you can then install the
	script with your visual and security preferences.  

	Read all steps before you perform them 
	  1) open an Internet browser
	  2) type in the path to the setup.cgi script you just uploaded.
	  3) fill in the requested information.
	  4) Click on the install button at the bottom of the program.
	  5) if you gave all the required information, the program will display security help.
	  6) read the help screen that opens.
	  7) do what the help screen asks (if you already have not)
	  8) read it then, as the script deletes its self after you run it.

	if you ever need to reinstall anything, you must re uploaded the "setup.cgi".
	and remember, you can change any of that information in the admin menu, after you 
	install the script.

 ** After you install **
	You should go to the subseven page (www.sub7page.com) to read how to setup the server
	so that it will record information with this script.
	
	and if you should ever get the message YOU ARE BANNED, that is a program added in that 
	prevents BRUTE FORCE.  you will get this message if you enter a wrong pass 10 times.  
	the ban only lasts 12-24 hours.  You must wait this time out, there is very little 
	you can do, other then using the correct login info.


 ** MORE HELP **
	A help screen can be found by typing 
	
	www.yoursite.com/cgi-bin/subseven.cgi?action=about

	from that location, you can page me or get my e-mail, icq number, and web address.
	Questions will not be answered if they are answered in the sub7page FAQ and they
	most likely are, so check there first.  An updated version of this script will be
	found at www.black-fire.net and possibly www.sub7page.com
	


###################################################################
#                     +SUBSEVEN LOGGER+                           #
###################################################################
#                                                                 #
# SubSeven is provided 'as-is', without any express or implied    #
# warranty. in no event will the author be held liable for any    #
# damages arising from the use of it.                             #
#                                                                 #
# The author can't be held responsible for any illegal action(s)  #
# arising from the use of this software. Sub7 is provided for     #
# educational purposes only!                                      #
#                                                                 #
#                 SUBSEVEN CAN BE FOUND AT                        #
#                    www.sub7page.com                             #
#                                                                 #
###################################################################
# There is nothing in this file you need to edit, in fact you     #
# may cause harm just by changing a few letters.  If however      #
# the first line of this program is not the path to PERL on       #
# your server, you need to change that.  But that is all, no      #
# more.  Please Read the README.txt that you received with this    #
# file.  all questions will be reviewed there.                    #
#                                                                 #
# There is no way to modify this script so that it will retrieve  #
# information that it already does not.                           #
###################################################################